I created this to help scrape keywords out of text files. Mostly I use it to scrape GeSHi language files and remove the bits I need.
